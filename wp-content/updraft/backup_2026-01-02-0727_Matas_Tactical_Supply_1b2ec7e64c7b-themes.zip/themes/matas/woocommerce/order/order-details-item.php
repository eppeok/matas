<?php
/**
 * Order Item Details
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/order/order-details-item.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! apply_filters( 'woocommerce_order_item_visible', true, $item ) ) {
	return;
}
?>


<tr class="<?php echo esc_attr( apply_filters( 'woocommerce_order_item_class', 'woocommerce-table__line-item order_item', $item, $order ) ); ?>">

    <!-- PRODUCT NAME + SEAT META -->
    <td class="woocommerce-table__product-name product-name">

        <?php
        $is_visible        = $product && $product->is_visible();
        $product_permalink = apply_filters(
            'woocommerce_order_item_permalink',
            $is_visible ? $product->get_permalink( $item ) : '',
            $item,
            $order
        );

        // Product Name (with link if visible)
        echo wp_kses_post(
            apply_filters(
                'woocommerce_order_item_name',
                $product_permalink
                    ? sprintf( '<a href="%s">%s</a>', $product_permalink, $item->get_name() )
                    : $item->get_name(),
                $item,
                $is_visible
            )
        );

        // Quantity
        $qty          = $item->get_quantity();
        $refunded_qty = $order->get_qty_refunded_for_item( $item_id );

        if ( $refunded_qty ) {
            $qty_display = '<del>' . esc_html( $qty ) . '</del> <ins>' . esc_html( $qty - ( $refunded_qty * -1 ) ) . '</ins>';
        } else {
            $qty_display = esc_html( $qty );
        }

       

        // Hooks before meta
        do_action( 'woocommerce_order_item_meta_start', $item_id, $item, $order, false );

        // Seat(s) Meta (ACF Custom Data)
        echo '<div class="wc-product-meta">';
        wc_display_item_meta( $item );
        echo '</div>';

        // Hooks after meta
        do_action( 'woocommerce_order_item_meta_end', $item_id, $item, $order, false );
        ?>

    </td>

    <!-- UNIT PRICE -->
    <td class="woocommerce-table__product-price product-price">
        <?php
        // subtotal / qty = unit price
        $unit_price = $item->get_subtotal() / max( 1, $qty );
        echo wc_price( $unit_price );
        ?>
    </td>

    <!-- QUANTITY -->
    <td class="woocommerce-table__product-quantity product-quantity">
        <?php echo esc_html( $qty ); ?>
    </td>

    <!-- LINE SUBTOTAL -->
    <td class="woocommerce-table__product-total product-total">
        <?php echo $order->get_formatted_line_subtotal( $item ); ?>
    </td>

</tr>

<?php if ( $show_purchase_note && $purchase_note ) : ?>

<tr class="woocommerce-table__product-purchase-note product-purchase-note">
    <td colspan="4">
        <?php echo wpautop( do_shortcode( wp_kses_post( $purchase_note ) ) ); ?>
    </td>
</tr>

<?php endif; ?>